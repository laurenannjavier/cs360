package com.example.lauren_annjavier;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    // This declares the instance variables for the database helper, username input, password input, and login button
    private DBHelper dbHelper;
    private EditText usernameEditText, passwordEditText;
    private Button loginButton;

    @SuppressLint("MissingInflatedId") // This suppresses warnings related to the missing ID inflation
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // This sets the layout for this activity
        setContentView(R.layout.activity_login);

        // This initializes the DBHelper to handle the database operations
        dbHelper = new DBHelper(this);

        // This links the UI components from the XML layout to the code
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.login_button);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // This retrieves the input values from the username and password EditTests
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (dbHelper.checkUser(username, password)) {
                    Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, WeightListActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
