package com.example.lauren_annjavier;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddWeightActivity extends AppCompatActivity {
    // This declares instance variables for the database helper, data input, weight input, and add button
    private DBHelper dbHelper;
    private EditText dateEditText, weightEditText;
    private Button addWeightButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // This sets the layout for this activity
        setContentView(R.layout.activity_add_weight);

        // This initializes the DBHelper to handle the database operations
        dbHelper = new DBHelper(this);
        dateEditText = findViewById(R.id.date_edit_text);
        weightEditText = findViewById(R.id.weight_edit_text);
        addWeightButton = findViewById(R.id.save_button);

        // This sets an OnClickListener for the 'Add Weight' button
        addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // This retrieves the input values from the date and weight EditTexts
                String date = dateEditText.getText().toString();
                float weight = Float.parseFloat(weightEditText.getText().toString());

                // This inserts the date and weight into the database, then shows a Toast message indicating success or failure.
                if (dbHelper.insertWeight(date, weight)) {
                    Toast.makeText(AddWeightActivity.this, "Weight added successfully", Toast.LENGTH_SHORT).show();
                   // This is to clear the input fields after a successful insert
                    dateEditText.setText("");
                    weightEditText.setText("");
                } else {
                    // This displays an error message if the insertion fails
                    Toast.makeText(AddWeightActivity.this, "Failed to add weight", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
