package com.example.lauren_annjavier;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    // This requests code for SMS permission
    private static final int SMS_PERMISSION_CODE = 100;
    // This declares EditTests for username and password input
    private EditText editTextUsername, editTextPassword;
    // This declares Buttons for login and registration
    private Button buttonLogin, buttonRegister;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // This sets the layout for this activity
        setContentView(R.layout.activity_main);

        // THis links the UI components from the xml layout to the code
        editTextUsername = findViewById(R.id.username);
        editTextPassword = findViewById(R.id.password);
        buttonLogin = findViewById(R.id.login_button);
        buttonRegister = findViewById(R.id.register_button);

        // This sets an OnClickListener for the 'Login' button
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser(); // This calls the LoginUser method when the button is clicked
            }
        });

        // This sets an OnClickerListener for the 'register' button
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser(); // This calls the registerUser method when the button is clicked
            }
        });
    }

    // This method is to handle user login
    private void loginUser() {
        // This is to retrieve and trim the username and password from the EditTexts
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        // This is to check if the username or password is empty
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return; // This exits the method if input is invalid
        }

        // This initializes DBHelper to check user credentials
        DBHelper dbHelper = new DBHelper(this);
        boolean isValid = dbHelper.checkUser(username, password); // This validates credentials
        if (isValid) {
            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
            checkAndRequestSMSPermission(); // This checks for the SMS permission
            // This starts the WeightListActivity if login is successful
            Intent intent = new Intent(MainActivity.this, WeightListActivity.class);
            startActivity(intent);
            finish(); // This closes main to prevent returning to it
        } else {
            // This shows the error message if the credentials are invalid
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    // This method is to handle user registration
    private void registerUser() {
        // This is to retrieve and trim the username and password from the EditTexts
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        // This is to check if the username or password is empty
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return; // THis is to exit the method if the input is invalid
        }

        // This initializes DBHelper to insert new user credentials
        DBHelper dbHelper = new DBHelper(this);
        boolean isRegistered = dbHelper.insertUser(username, password);
        if (isRegistered) {
            // This shows the success message for registration
            Toast.makeText(this, "User registered successfully!", Toast.LENGTH_SHORT).show();
        } else {
            // This shows the error message if registration fails
            Toast.makeText(this, "Registration failed. Try again.", Toast.LENGTH_SHORT).show();
        }
    }

    // This method is to check and request SMS permission
    private void checkAndRequestSMSPermission() {
        // This is to check if the SMS permission has been granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // This si to request SMS permission if not granted
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    // THis handles the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // This is to check if the request code matches the SMS permission request
        if (requestCode == SMS_PERMISSION_CODE) {
           // This is to check if permission was granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                // This notifies the user that SMS permission was denied
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
