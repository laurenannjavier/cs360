package com.example.lauren_annjavier;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    // This declares EditTexts for username and password input
    private EditText usernameEditText, passwordEditText;
    // This declares an instance of DBHelper for database operations
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // This sets the layout for this activity
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // This initializes the DBHelper for database interaction
        dbHelper = new DBHelper(this);
        // This links the UI components from the XML layout to the code
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        Button registerButton = findViewById(R.id.register_button); // This initializes the 'Register' button

        // This sets an OnClickListener for the 'Register' button
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // This retrieves the username and password entered by the user
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // This inserts user credentials into the database and checks if the registration was successful
                if (dbHelper.insertUser(username, password)) {
                    // This notifies the user of successful registration
                    Toast.makeText(RegisterActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();
                    finish();// This closes the activity and returns to the previous screen
                } else {
                    // This notifies the user if registration failed
                    Toast.makeText(RegisterActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
