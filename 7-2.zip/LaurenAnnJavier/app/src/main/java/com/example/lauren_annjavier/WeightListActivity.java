package com.example.lauren_annjavier;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class WeightListActivity extends AppCompatActivity {

    // This declares an instance of DBHelper for database operations
    private DBHelper dbHelper;
    // This is for displaying the list of weights in a GridView
    private GridView weightGridView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // This sets the layout for this activity
        setContentView(R.layout.activity_weight_list);

        // This initializes the DBHelper for database access and management
        dbHelper = new DBHelper(this);
        // This is for inserting test data into the database for demonstration purposes
        dbHelper.insertTestData();

        // This links the GridView from the layout to the code for displaying data
        weightGridView = findViewById(R.id.weight_grid_view);
        // This calls the method to fetch and display weight data from the database
        displayWeightData();
    }

    private void displayWeightData() {
        // This is for retrieving all weight data from the database
        Cursor cursor = dbHelper.getAllWeights();
        // This checks if there is data to display
        if (cursor != null && cursor.getCount() > 0) {
            String[] fromColumns = {DBHelper.COLUMN_DATE, DBHelper.COLUMN_WEIGHT};
            // This defines the view IDs to bind the data to in the layout
            int[] toViews = {R.id.date_text_view, R.id.weight_text_view};

            // This is for setting up an adapter to map database data to GridView items
            SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                    this, R.layout.weight_grid_item, cursor, fromColumns, toViews, 0);

            // This is for binding the adapter to the GridView to display the data
            weightGridView.setAdapter(adapter);
        } else {
            // This notifies the user if there is no data to display
            Toast.makeText(this, "No data to display", Toast.LENGTH_SHORT).show();
        }
    }
}
